# TODO

- [] Understand the relationship between clickThrough and hideDrawings
- [] Nicer icon
- [] How do we summon the thing properly?
- [] Serialize the toolbar state globally
- [] Make the toolbar draggable?