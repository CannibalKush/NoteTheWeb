# firefox-draw
It's a Firefox extension that lets you draw on web pages.
